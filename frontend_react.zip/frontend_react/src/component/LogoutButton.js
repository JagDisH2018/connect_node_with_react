import React from 'react';
import axios from 'axios';

const LogoutButton = () => {
  const handleLogout = async () => {
    try {
      const response = await axios.get('/logout');
      console.log(response.data.message);
      // Perform any additional logout actions (e.g., clearing local storage or cookies)
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <button onClick={handleLogout}>Logout</button>
  );
};

export default LogoutButton;
