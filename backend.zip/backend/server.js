const express = require('express');
const mysql = require('mysql');

const app = express();
app.use(express.json());

// Connect to MySQL database
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'root',
  database: 'login_logout',
});


app.get("/api", (req,res)=>{
    res.json({"users":["userOne","userTwo","userThree","userFour","userFive","6"]})
})

app.get("/res", (req,res)=>{
  res.json({"users":["1","2","3","4","5","6"]})
})

const port = 3001;
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
